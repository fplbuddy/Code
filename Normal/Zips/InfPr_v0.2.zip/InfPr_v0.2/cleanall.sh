rm -f Checks/* Fields/* Spectra/* Transfers/*
